var pwd = "admin123";
if(pwd == "admin1234") console.log("contraseña correcta")
if(pwd != "admin1234") console.log("verifique sus datos")