var numero = 3;
if(numero  < 10) console.log("el numero es menor que 10")
