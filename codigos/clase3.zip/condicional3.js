var numero = 10;
if(numero  < 10) console.log("el numero es menor que 10")
if(numero  > 10) console.log("el numero es mayor que 10")
if(numero == 10) console.log("el numero es 10")