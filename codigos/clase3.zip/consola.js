var valor1 = process.argv[2];
var valor2 = process.argv[3];
var valor3 = process.argv[4];

console.log("los valores recibidos son:")
console.log(valor1)
console.log(valor2)
console.log(valor3)
