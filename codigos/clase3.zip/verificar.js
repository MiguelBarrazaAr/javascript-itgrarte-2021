var pwd = process.argv[2];
if(pwd == "admin1234") {
    console.log("contraseña correcta")
} else {
    console.log("verifique sus datos")
    console.log("su intento fue registrado")
}