var decoracion = "+";
var mensaje = decoracion+decoracion+"hola mundo"+decoracion+decoracion
console.log(mensaje)