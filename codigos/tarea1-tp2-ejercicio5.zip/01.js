//var mes = process.argv[2];
var mes = 5;
if(mes == 1) {
    console.log("enero");}
if(mes == 2) {
    console.log("febrero");}
if(mes == 3) {
    console.log("marzo"); }
if(mes == 4) {
    console.log("abril"); }
if(mes == 5) {
    console.log("mayo"); }
if(mes == 6) {
    console.log("junio"); }
if(mes == 7) {
    console.log("julio"); }
if(mes == 8) {
    console.log("agosto"); }
if(mes == 9) {
    console.log("septiembre"); }
if(mes == 10) {
    console.log("octubre"); }
if(mes == 11) {
    console.log("noviembre"); }
if(mes == 12) {
    console.log("disiembre"); }
