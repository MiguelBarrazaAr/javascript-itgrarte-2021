var mes= 8;
// var mes= process.argv[2];

if(mes==1){console.log("Enero");
}else if(mes==2){console.log("Febrero");
}else if(mes==3){console.log("Marzo");
}else if(mes==4){console.log("Abril");
}else if(mes==5){console.log("Mayo");
}else if(mes==6){console.log("Junio");
}else if(mes==7){console.log("Julio");
}else if(mes==8){console.log("Agosto");
}else if(mes==9){console.log("Septiembre");
}else if(mes==10){console.log("Octubre");
}else if(mes==11){console.log("Noviembre");
}else if(mes==12){console.log("Diciembre");
}else{console.log("Número incorrecto");
} /* Esta última condición está para controlar que se ingresen números del 1 al12. */