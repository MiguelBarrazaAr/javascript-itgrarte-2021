var nombre = "miguel";
var numero = 50;
var reales = 5.3;
console.log(numero+15);
console.log(numero-5);
console.log(numero*2);
console.log(numero/5);
console.log(reales*2);
console.log(reales*2+3);