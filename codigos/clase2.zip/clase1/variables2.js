var nombre = "miguel";
var numero = 53;
var reales = 5.3;
console.log("hola "+nombre);
console.log("soy "+nombre+", me gusta javascript");
