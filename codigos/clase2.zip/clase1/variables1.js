var nombre = "miguel";
var numero = 53;
console.log(nombre);
console.log(numero);