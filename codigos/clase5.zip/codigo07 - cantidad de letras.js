var texto = "hola mundo";

function cantidadDeLetras(cadena) {
    var contar = cadena.length
    return contar;
}

var cantidad = cantidadDeLetras("ahora voy a poner un texto mucho más largo.");
console.log("tu texto tiene "+cantidad+" letras.")