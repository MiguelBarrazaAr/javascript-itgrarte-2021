var num1 = 2;
var num2 = 3;
if(num1 > num2) {
  console.log(num1+" es mayor que "+num2)
}

if(num1 < num2) {
  console.log(num1+" es menor que "+num2)
}