var num1 = 3;
var num2 = 3;
if(num1 > num2) {
    console.log(num1+" es mayor que "+num2)
} else if(num1 == num2) {
    console.log("los 2 numeros son iguales")
} else {
    console.log(num1+" es menor que "+num2)
}
