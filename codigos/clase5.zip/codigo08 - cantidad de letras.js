var texto = "hola mundo";

function cantidadDeLetras(cadena) {
    var contar = cadena.length
    return contar;
}

var cantidad = cantidadDeLetras("ahora voy a poner un texto mucho más largo.");
console.log("tu texto tiene "+cantidad+" letras.")
var cantidad = cantidadDeLetras("estamos en un curso de javascript y contaremos las letras de este texto largo.");
console.log("el segundo texto  tiene "+cantidad+" letras.")