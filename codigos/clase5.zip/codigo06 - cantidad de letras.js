var texto = "hola mundo";

function cantidadDeLetras(cadena) {
    var contar = cadena.length
    console.log("el texto tiene "+contar+" letras.")
}

cantidadDeLetras(texto);
cantidadDeLetras("ahora voy a poner un texto mucho más largo.");