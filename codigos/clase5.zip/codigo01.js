var num1 = 5;
var num2 = 3;
if(num1 > num2) {
  console.log(num1+" es mayor que "+num2)
}