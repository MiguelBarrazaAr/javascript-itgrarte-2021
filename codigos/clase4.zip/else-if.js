﻿var n = process.argv[2];

if (n < 5) console.log("es menor que 5");
else if (n < 7) console.log("es menor que 7");
else if (n < 10) console.log("es menor que 10");

