﻿var num = parseInt(process.argv[2]);

if (num === 3)
	console.log("es correcto");
else
		console.log("es incorrecto");