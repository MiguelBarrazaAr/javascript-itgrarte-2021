﻿function saludar() {
	console.log("Sean todos bienvenidos y bienvenidas al fabuloso mundo de las funciones");
}

saludar();