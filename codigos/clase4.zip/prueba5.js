﻿var num1 = 20;
var num2 = 30;

function sumar(num1, num2){
	return num1 + num2;
}

var resultado = sumar(num1, num2);

console.log(resultado);
