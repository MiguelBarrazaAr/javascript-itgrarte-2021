﻿function multiplicar(a,b){
	console.log(a*b);
}

multiplicar(7,8);