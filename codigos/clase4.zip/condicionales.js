﻿var num = process.argv[2];

if (num == 1)
	console.log("Enero");
if (num  == 2)
	console.log("Febrero");
if (num == 3)
	console.log("Marzo");
if (num == 4)
	console.log("Abril");
if (num == 5)
	console.log("Mayo");
if (num == 6)
	console.log("Junio");
if (num == 7)
	console.log("Julio");
if (num == 8)
	console.log("Agosto");
if (num == 9)
	console.log("Septiembre");
if (num == 10)
	console.log("Octubre");
if (num == 11)
	console.log("Noviembre");
if (num == 12)
	console.log("Diciembre");
else
	console.log("el dato ingresado no es un número válido");