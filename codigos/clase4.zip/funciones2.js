﻿var name = process.argv[2];

function saludar(nombre) {
	console.log("Hola " + nombre + ". ¡Que tengas un excelente día!");
}

saludar(name);