﻿var x = 0;

function sumar() {
	x++;
	return x
}

var result = sumar();
console.log(result);