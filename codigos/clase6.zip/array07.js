let texto = "hola mundo"
console.log(texto[0])