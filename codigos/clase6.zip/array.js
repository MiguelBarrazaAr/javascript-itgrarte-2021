var dias = ["lunes", "martes", "miércoles", "jueves", "viernes"];
console.log(dias.length)