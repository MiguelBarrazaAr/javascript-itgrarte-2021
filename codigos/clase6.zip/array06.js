let nums = [1,3,2,1,5,3,1,8,1,4,1,1,5,1,2,1]
let cantidad = 0
console.log("la cantidad es: "+cantidad)
for(let x of nums) {
    console.log("el numero es "+x)
    if(x == 1) {
        cantidad = cantidad+1
        console.log("la cantidad es: "+cantidad)
    } else {
        console.log("no es un 1")
    }
}
console.log("hay "+cantidad+" unos")