let texto = "hola mundo"
for(let letra of texto) {
    console.log(letra)
}