let texto = "estoy aprendiendo a programar en javascript para hacer muchos scripts"
let cantidad = texto.length
let palabras = texto.split(" ")
console.log("mi texto tiene "+cantidad+" caracteres")

console.log("palabras: ")
console.log(palabras)
let cantidadDePalabras = palabras.length
console.log("mi texto tiene "+cantidadDePalabras+" cantidad palabras")