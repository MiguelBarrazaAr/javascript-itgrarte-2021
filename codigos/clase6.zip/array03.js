var dias = ["lunes", "martes", "miércoles", "jueves", "viernes"]
for(let x of dias) {
    console.log(x)
}