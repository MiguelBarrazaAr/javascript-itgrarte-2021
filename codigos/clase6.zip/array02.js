var dias = ["lunes", "martes", "miércoles", "jueves", "viernes"]
for(let x in dias) {
    console.log(x)
}