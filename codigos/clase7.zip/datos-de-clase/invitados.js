﻿var listaDeInvitados = ["Franco", "Mariela", "Julián", "Julieta", "Jorge", "Marcela", "Lucas", "Nancy", "Gerardo", "Miguel", "Martín", "Patricia"];
var nombre = process.argv[2];
