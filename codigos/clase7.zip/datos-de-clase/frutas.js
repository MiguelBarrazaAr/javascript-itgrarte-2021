﻿var frutas = ["Manzana", "Banana", "Naranja", "Uva", "Durazno", "Frutilla", "Mango", "Pera"]
