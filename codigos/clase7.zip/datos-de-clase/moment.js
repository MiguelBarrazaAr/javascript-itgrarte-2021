﻿var moment = require('moment');
var fecha = moment().format('DD/MM/YYYY HH:mm');
console.log(fecha)