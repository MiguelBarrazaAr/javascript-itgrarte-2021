﻿var diasHabiles = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"];
var finDeSemana = ["Sábado", "Domingo"];
