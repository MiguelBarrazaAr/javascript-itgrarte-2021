﻿var moment = require('moment');
var fecha = moment().format('HH:mm');
console.log(fecha)