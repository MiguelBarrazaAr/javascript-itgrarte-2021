﻿var x = process.argv[2]
var meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
if(x > 12) {
    console.log("no es un mes válido")
} elseif (x < 1) {
    console.log("no molestes")
} else {
    console.log(meses[x-1])
}