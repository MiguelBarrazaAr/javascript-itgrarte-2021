﻿var frutas = ["Manzana", "Banana", "Naranja", "Uva", "Durazno", "Frutilla", "Mango", "Pera"]
frutas.push("sandia")
//console.log(frutas)
frutas.pop()
frutas.pop()
frutas.shift()
frutas.unshift("frutillas")
console.log(frutas)