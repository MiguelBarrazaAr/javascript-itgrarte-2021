﻿const  valor = 5
valor=6
console.log(valor)