﻿var diasHabiles = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"];
var finDeSemana = ["Sábado", "Domingo"];

var final = diasHabiles.concat(finDeSemana)

console.log(final[0])