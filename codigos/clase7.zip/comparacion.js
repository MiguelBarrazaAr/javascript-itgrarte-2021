﻿let valor = 6
let f = false
let v = true

if(valor == 5) {
    console.log("es verdadero")
} else {
    console.log("es falso")
}

let exp = valor == 6
console.log(exp)