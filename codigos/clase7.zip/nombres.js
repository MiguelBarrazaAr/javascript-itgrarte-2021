﻿var nombres = ["ana", "marcos", "romina", "andres", "alberto", "alma", "mariano", "marcela", "ariel", "ramiro"]

for(let n of nombres) {
    if(n.charAt(0) == "a") {
        console.log(n)
    }
}