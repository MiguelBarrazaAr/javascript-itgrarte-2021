﻿var listaDeInvitados = ["Franco", "Mariela", "Julián", "Julieta", "Jorge", "Marcela", "Lucas", "Nancy", "Gerardo", "Miguel", "Martín", "Patricia"];
var nombre = process.argv[2];
if(listaDeInvitados.indexOf(nombre) > 0) {
    console.log("pase por favor")
} else {
    console.log("siga intentando")
}